//! \file bfsalgorithm.cpp

#include <bits/stdc++.h>
#include "bfsalgorithm.h"
#include "../API/api.h"
#include "../Direction/direction.h"
#include <queue>
#include <iostream>


/** @brief Breadth First Search (BFS) Algorithm */
/** @detail BFS search algorithm process calls maze pointers to determine cell locations
 * and wall positions. Wall positions are read at the robot current position and clear paths determined.
 * Queue of points are built to find a solution to maze and used to trace path from start to goal
 */
 
int row=0;
int col =0;
 
 /** @detail Sets start point and goal boundary with green wall markers. */
fp::Algorithm::Algorithm(fp::Maze* maze_ptr)
{
	/** @brief sets start cell to green after clearing previous colors*/
    API::clearAllColor();
	API::setColor(0, 0, 'G');
	
	/** @brief sets goal cell (center of maze) to green */
	maze_ptr->colorCenter('G');
}

/** @detail Solve function uses maze_ptr to read wall positions from current robot position.
 * readWall will return positions of walls present around robot location and identify open paths
 */
 
bool isValid(int row, int col) 
	{ 
		// return true if row number and column number 
		// is in range 
		return (row >= 0) && (row < 16) && 
			   (col >= 0) && (col < 16); 
	}  
 

void fp::Algorithm::solve(fp::Maze* maze_ptr, fp::LandBasedRobot* wheel_robot)
{
	std::array<std::array <int,2>, 4> goal_pts  = {{{7,7}, {7,8}, {8,7}, {8,8}}};
	
	struct Point 
	{ 
		int x; 
		int y; 
	};
	
	// A Data Structure for queue used in BFS 
	struct queueNode 
	{ 
		Point pt;  // The cordinates of a cell 
		//Point Pt;
		int dist;  // cell's distance of from the source 
	}; 
	
	maze_ptr->readWall(0, 0, wheel_robot->get_direction());

	int x = wheel_robot->get_x();
	int y = wheel_robot->get_y();
	
	if (isValid(x, y)){
		for (int i=0;i<4;i++){
			if (x==goal_pts[i][0] && y == goal_pts[i][1])
			{
				std::cout<< "Goal is Reached"<<std::endl;
			}
		}
	}

//	int rowNum[] = {0, 1, 0, -1}; 
//	int colNum[] = {-1, 0, 1, 0}; 

//int BFS(int Maze[46][31],Point src, Point dest){
//	
//	if (src.x==dest.x && src.y==dest.y) //is goal then
//	{
//		//cout<<"Flag 2"<<endl;
//		writetotext(Maze,src.x,src.y,dest.x,dest.y);
//		return true;
//	}
//	
	
  
    bool visited[16][16]; 
    memset(visited, false, sizeof visited); 
      
    // Mark the source cell as visited 
    visited[x][y] = true; 
  
    // Create a queue for BFS 
    std::queue<queueNode> q; 
	
	
	int px=0;
	int py=0;
    // Distance of source cell is 0 
    queueNode s = {(px,py), 0}; 
    q.push(s);  // Enqueue source cell 
  
    // Do a BFS starting from source cell 
    while (!q.empty()) 
    { 
        queueNode curr = q.front(); 
        Point pt = curr.pt; 
		
		std::cout <<"x : "<< pt.x <<"  y : "<< pt.y <<std::endl;
		
        // If we have reached the destination cell, 
        // we are done 
        for (int i=0;i<4;i++){
			if (pt.x==goal_pts[i][0] && pt.y == goal_pts[i][1])
			{
				std::cout<< "Goal is Reached"<<std::endl;
			}
		}
        // Otherwise dequeue the front cell in the queue 
        // and enqueue its adjacent cells 
        q.pop(); 
  
//        for (int i = 0; i < 4; i++) 
//        { 
//
//            int row = pt.x + rowNum[i]; 
//            int col = pt.y + colNum[i]; 
//			
			
		
		// if adjacent cell is valid, has path and 
		// not visited yet, enqueue it. 
		if ((isValid(row,col))) //&& (!visited[row][col]) )
		{ 
		queueNode Adjcell = { {row, col}, 
							  curr.dist + 1 }; 
									  
									  
		char curr_direction = wheel_robot->get_direction();
		
		std::cout << "Current Direction "<< curr_direction << std::endl;
		
		
		switch(curr_direction){
		case Direction::NORTH : if(((API::wallFront())&& ((isValid((pt.x)+0 , (pt.y)+1)) && (!visited[((pt.x)+0)][((pt.y)+1)])))){
			
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)+1)}, 'n'};
							//std::cout << "Adjcell"<< Adjcell[1]<<std::endl;
							q.push(Adjcell); 
							//mark cell as visited and enqueue it 
							visited[((pt.x)+0)][((pt.y)+1)] = true; 
							
						};
						if(((API::wallRight())&& ((isValid((pt.x)+1 , (pt.y)+0)) && (!visited[((pt.x)+1)][((pt.y)+0)])))){
							
							queueNode Adjcell = { {((pt.x)+1), ((pt.y)+0)}, 'e'};
							
							
							q.push(Adjcell);  
							//mark cell as visited and enqueue it 
							visited[((pt.x)+1)][((pt.y)+0)] = true; 
							
						};
						if(((API::wallLeft())&& ((isValid((pt.x)-1 , (pt.y)+0)) && (!visited[((pt.x)-1)][((pt.y)+0)])))){
							queueNode Adjcell = { {((pt.x)-1), ((pt.y)+0)}, 'w'}; 
							q.push(Adjcell); 
							//mark cell as visited and enqueue it 
							visited[((pt.x)-1)][((pt.y)+0)] = true;
						};
						break;
		case Direction::EAST : if(((API::wallFront())&& ((isValid((pt.x)+1 , (pt.y)+0)) && (!visited[((pt.x)+1)][((pt.y)+0)])))){
							queueNode Adjcell = { {((pt.x)+1), ((pt.y)+0)}, 'e'}; 
							q.push(Adjcell); 
							//mark cell as visited and enqueue it 
							visited[((pt.x)+1)][((pt.y)+0)] = true; 
						};
						if(((API::wallRight())&& ((isValid((pt.x)+0 , (pt.y)-1)) && (!visited[((pt.x)+0)][((pt.y)-1)])))){
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)-1)}, 's'}; 
							q.push(Adjcell); 
							visited[((pt.x)+0)][((pt.y)-1)] = true; 
						};
						if(((API::wallLeft())&& ((isValid((pt.x)+0 , (pt.y)+1)) && (!visited[((pt.x)+0)][((pt.y)+1)])))){
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)+1)}, 'n'}; 
							q.push(Adjcell); 
							visited[((pt.x)+0)][((pt.y)+1)] = true; 
						};
						break;
		case Direction::SOUTH : if(((API::wallFront())&& ((isValid((pt.x)+0 , (pt.y)-1)) && (!visited[((pt.x)+0)][((pt.y)-1)]) ))){
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)-1)}, 's'}; 
							q.push(Adjcell); 
							//mark cell as visited and enqueue it 
							visited[((pt.x)+0)][((pt.y)-1)] = true;
						};
						if(((API::wallRight())&& ((isValid((pt.x)-1 , (pt.y)+0)) && (!visited[((pt.x)-1)][((pt.y)+0)]) ))){
							queueNode Adjcell = { {((pt.x)-1), ((pt.y)+0)}, 'w'}; 
							q.push(Adjcell);
							//mark cell as visited and enqueue it 
							visited[((pt.x)-1)][((pt.y)+0)] = true; 
						};
						if(((API::wallLeft())&& ((isValid((pt.x)+1 , (pt.y)+0)) && (!visited[((pt.x)+1)][((pt.y)+0)]) ))){
							queueNode Adjcell = { {((pt.x)+1), ((pt.y)+0)}, 'e'}; 
							q.push(Adjcell);
							//mark cell as visited and enqueue it 
							visited[((pt.x)+1)][((pt.y)+0)] = true;
						};
						break;
		case Direction::WEST : if(((API::wallFront())&& ((isValid((pt.x)-1 , (pt.y)+0)) && (!visited[((pt.x)-1)][((pt.y)+0)]) ))){
							queueNode Adjcell = { {((pt.x)-1), ((pt.y)+0)}, 'w'}; 
							q.push(Adjcell);
							//mark cell as visited and enqueue it 
							visited[((pt.x)-1)][((pt.y)+0)] = true;  
						};
						if(((API::wallRight())&& ((isValid((pt.x)+0 , (pt.y)+1)) && (!visited[((pt.x)+0)][((pt.y)+1)]) ))){
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)+1)}, 'n'}; 
							q.push(Adjcell);
							//mark cell as visited and enqueue it 
							visited[((pt.x)+0)][((pt.y)+1)] = true;  
						};
						if(((API::wallLeft())&& ((isValid((pt.x)+0 , (pt.y)-1)) && (!visited[((pt.x)+0)][((pt.y)-1)]) ))){
							queueNode Adjcell = { {((pt.x)+0), ((pt.y)-1)}, 's'}; 
							q.push(Adjcell);
							//mark cell as visited and enqueue it 
							visited[((pt.x)+0)][((pt.y)-1)] = true;  
						};
						break;
}

                
            } 
        
    } 
  
//     Return -1 if destination cannot be reached 
//    return 0; 
	
	
}
	
	


fp::Algorithm::~Algorithm()
{
}